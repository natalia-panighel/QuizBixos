
import { useState } from "react";
import { motion } from "framer-motion";

const questions = [
  {
    question: "Chegou a semana de provas! Seu mood é:",
    options: [
      { text: "Eu nasci pra isso, vamo que vamo", type: "Bixo Líder" },
      { text: "Calma, respira, medita, vai dar certo", type: "Bixo Monge" },
      { text: "Chora no banho e depois vai", type: "Bixo Caótico" },
      { text: "Café, Red Bull e seja o que Deus quiser", type: "Bixo Cientista" }
    ]
  },
  {
    question: "Quando você pensa no trote universitário, você:",
    options: [
      { text: "Tô contando os dias! Quero muito participar!", type: "Bixo Festeiro" },
      { text: "Tô ansioso, mas espero que seja divertido.", type: "Bixo Conselheiro" },
      { text: "Se rolar uma opção light, tô dentro.", type: "Bixo Vibes" },
      { text: "Prefiro observar de longe e ver no que dá.", type: "Bixo Fantasma" }
    ]
  }
];

const results = {
  "Bixo Raiz": "Tradicional, animado e ama a bagunça!",
  "Bixo Vibes": "Tranquilo, leve e paz e amor.",
  "Bixo Monge": "Zen, paciente e o mais de boas da galera.",
  "Bixo Festeiro": "Extrovertido, topa qualquer rolê!",
  "Bixo Líder": "Organizador nato e sempre toma a frente.",
  "Bixo Fantasma": "Reservado, some mas sempre aparece na hora certa.",
  "Bixo Atleta": "Competitivo, ativo e presente em todos eventos.",
  "Bixo Conselheiro": "Empático, amigo de todos!",
  "Bixo Cientista": "Analítico, curioso e cheio de planos.",
  "Bixo Caótico": "Imprevisível e 100% divertido!"
};

export default function Quiz() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState([]);
  const [showResult, setShowResult] = useState(false);

  const handleAnswer = (type) => {
    setAnswers([...answers, type]);
    const nextQuestion = currentQuestion + 1;
    if (nextQuestion < questions.length) {
      setCurrentQuestion(nextQuestion);
    } else {
      setShowResult(true);
    }
  };

  const calculateResult = () => {
    const frequency = {};
    answers.forEach((type) => {
      frequency[type] = (frequency[type] || 0) + 1;
    });
    return Object.keys(frequency).reduce((a, b) => (frequency[a] > frequency[b] ? a : b));
  };

  if (showResult) {
    const resultType = calculateResult();
    return (
      <div className="flex flex-col items-center justify-center h-screen bg-green-900 text-white p-8">
        <motion.h1 initial={{ scale: 0 }} animate={{ scale: 1 }} className="text-4xl font-bold mb-6">
          Você é o {resultType}!
        </motion.h1>
        <p className="text-xl mb-8">{results[resultType]}</p>
        <button
          onClick={() => window.location.reload()}
          className="bg-green-600 hover:bg-green-500 px-6 py-3 rounded-full text-lg"
        >
          Refazer Quiz
        </button>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center h-screen bg-green-950 text-white p-8">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        <h2 className="text-2xl font-semibold mb-4 text-center">
          Pergunta {currentQuestion + 1} de {questions.length}
        </h2>
        <p className="text-lg mb-6 text-center">{questions[currentQuestion].question}</p>
        <div className="flex flex-col gap-4">
          {questions[currentQuestion].options.map((option, index) => (
            <button
              key={index}
              onClick={() => handleAnswer(option.type)}
              className="bg-green-700 hover:bg-green-600 px-6 py-3 rounded-xl shadow-lg"
            >
              {option.text}
            </button>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
